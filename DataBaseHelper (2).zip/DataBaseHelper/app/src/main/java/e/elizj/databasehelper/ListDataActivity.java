package e.elizj.databasehelper;

import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by elizj on 15-11-2017.
 */

public class ListDataActivity extends AppCompatActivity {
    private static final String TAG="ListDataActivity";
    Database mdatabase;
    private ListView mListView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState ){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
        mdatabase=new Database(this);
        mListView=(ListView)findViewById(R.id.listView);
        populateListView();



    }
    private void populateListView() {
        Log.d(TAG,"populateListView:Display Data in Listview");
        Cursor data  = mdatabase.getData();
        ArrayList<String> listData=new ArrayList<>();
        while (data.moveToNext())
        {listData.add(data.getString(1));
            ListAdapter adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
            mListView.setAdapter(adapter);

        }
    }




}
