package e.elizj.databasehelper;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    Database mDatabase;
    private Button btnadd, btnview;
    private EditText viewword,editText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewword = (EditText) findViewById(R.id.editText2);
        editText = (EditText) findViewById(R.id.editText);
        btnadd = (Button) findViewById(R.id.button);
        btnview = (Button) findViewById(R.id.button2);
        mDatabase = new Database(this);
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                String newEntry = viewword.getText().toString();
                AddData(newEntry);
                viewword.setText("");
            }

        });
        btnview.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });
    }


    public void AddData(String newEntry) {
        boolean insertData = mDatabase.putWord(newEntry, newEntry);
        if (insertData) {
            toastMessage("data successfully inserted");
        } else {
            toastMessage("Wrong Insertion");
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
    }
}
    
