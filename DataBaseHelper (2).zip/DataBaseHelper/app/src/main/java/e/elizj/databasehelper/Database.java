package e.elizj.databasehelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {
    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "Notebook.db";

    public static final String TABLE_NAME = "words";
    public static final String COL_ID = "ID";
    public static final String COL_EN = "en";
    public static final String COL_FR = "fr";


    private static final String SQL_CREATE_ENTRIES =
        "CREATE TABLE " + Database.TABLE_NAME + " (" +
            Database.COL_ID + " INTEGER PRIMARY KEY," +
            Database.COL_EN + " TEXT," +
            Database.COL_FR + " TEXT)";

    private static final String SQL_DELETE_ENTRIES =
        "DROP TABLE IF EXISTS " + Database.TABLE_NAME;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public boolean putWord(String en, String fr) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Database.COL_EN, en);
        values.put(Database.COL_FR, fr);

        db.insert(Database.TABLE_NAME, null, values);
        return true;
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query="SELECT * FROM "+TABLE_NAME;
        Cursor data = db.rawQuery(query,null);
        return data;

    }




    public ArrayList<ArrayList<String>> getWords() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + Database.TABLE_NAME,null);
        ArrayList<ArrayList<String>> rows = new ArrayList<>();

        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                ArrayList<String> row = new ArrayList<>();
                String en = cursor.getString(cursor.getColumnIndex(Database.COL_EN));
                String fr = cursor.getString(cursor.getColumnIndex(Database.COL_FR));
                row.add(en);
                row.add(fr);
                rows.add(row);

                cursor.moveToNext();
            }
        }

        return rows;
    }
/*
    Database db = Database(getApplicationContext());
     ArrayList<> rows = db.getWords();*/
}


